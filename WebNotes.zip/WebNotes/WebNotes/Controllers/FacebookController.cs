﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using Facebook;
using System.Web.Security;
//using WebNotes.Models;
using System.Net;
using System.IO;

namespace WebNotes.Controllers
{
    public class HomeController : Controller
    {

        //Параметры приложения  из developers.facebook.com/
        long ID_PROG = 1580111102041560;
        string SECRET_PROG = "b547f40074d6525327ab7e80a3efd759";

        public ActionResult Index()
        {
            return View();
        }

        public ActionResult Facebook()
        {
            var fb = new FacebookClient();
            var loginUrl = fb.GetLoginUrl(new
            {
                client_id = ID_PROG,
                client_secret = SECRET_PROG,
                redirect_uri = RedirectUri.AbsoluteUri,
                response_type = "code",
                scope = @"email,user_posts" // Если необходимо тогда здесь дописать нужные права
            });

            return Redirect(loginUrl.AbsoluteUri);
        }

        public ActionResult FacebookCallback(string code)
        {
            var fb = new FacebookClient();
            dynamic result = fb.Post("oauth/access_token", new
            {
                client_id = ID_PROG,
                client_secret = SECRET_PROG,
                redirect_uri = RedirectUri.AbsoluteUri,
                code = code
            });
            var accessToken = result.access_token;
            Session["AccessToken"] = accessToken;
            fb.AccessToken = accessToken;
            return RedirectToAction("Index", "Home");
        }

        private Uri RedirectUri
        {
            get
            {
                var uriBuilder = new UriBuilder(Request.Url);
                uriBuilder.Query = null;
                uriBuilder.Fragment = null;
                uriBuilder.Path = Url.Action("FacebookCallback");
                return uriBuilder.Uri;
            }
        }
    }
}